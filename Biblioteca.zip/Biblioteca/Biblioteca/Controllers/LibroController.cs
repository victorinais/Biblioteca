using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class LibroController : Controller {

    public IActionResult Ver(){
        return View();
    }

    public IActionResult Crear()
    {
        return View();
    }

    public IActionResult Actualizar()
    {
        return View();
    }
    public IActionResult Detalles()
    {
        return View();
    }
    public IActionResult Eliminar()
    {
        return View();
    }
}