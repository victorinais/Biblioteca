using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class AutenticarController : Controller
{
    public IActionResult Iniciar()
    {
        return View();
    }

    public IActionResult Registrar()
    {
        return View();
    }

}