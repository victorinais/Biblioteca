using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class AdministradorController : Controller
{
   public IActionResult Index()
   {
    return View();
   }

}