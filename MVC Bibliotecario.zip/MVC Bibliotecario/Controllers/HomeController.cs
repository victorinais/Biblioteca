using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class HomeController : Controller{

    public IActionResult Index(){
        return View();
    }

}