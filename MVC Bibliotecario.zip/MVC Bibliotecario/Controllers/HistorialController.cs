using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class HistorialController : Controller
{

    public IActionResult Ver()
    {
        return View();
    }
}